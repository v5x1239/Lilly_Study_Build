update pf_inform
set informversion='5.5.0.2490';

commit;

exit
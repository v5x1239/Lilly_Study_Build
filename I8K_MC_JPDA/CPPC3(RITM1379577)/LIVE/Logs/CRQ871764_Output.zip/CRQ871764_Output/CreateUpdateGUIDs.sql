SET SERVEROUTPUT ON FORMAT WRAPPED
Set heading on
set pagesize 0
set linesize 2000
set term on
set trimspool on
set feedback on
set verify on
spool UpdateGUIDs.log

call tra_pkg.start_tx('Update to current mapping GUID',1);
update cca_keyitem t
set t.value=replace(t.value,'{50D24B46-D46B-4129-A397-185BD2E63221}','{5FAD6A62-2BDB-41A0-8996-991ED9D2A491}')
where
value like'%{50D24B46-D46B-4129-A397-185BD2E63221}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{950B493C-3667-4547-BC67-0AF3081575E4}','{5FAD6A62-2BDB-41A0-8996-991ED9D2A491}')
where
value like'%{950B493C-3667-4547-BC67-0AF3081575E4}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{D5C5A402-DA3A-4767-BABB-8423C1F2CFFC}','{5FAD6A62-2BDB-41A0-8996-991ED9D2A491}')
where
value like'%{D5C5A402-DA3A-4767-BABB-8423C1F2CFFC}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}','{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}')
where
value like'%{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}','{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}')
where
value like'%{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}','{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}')
where
value like'%{6C791A08-AD99-46BA-B49F-7FFF1B420BBB}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{C347BA4C-BFB2-4F24-852A-B113BB6D9C01}','{9045F375-2050-4AB7-8A1A-6E221F0E0800}')
where
value like'%{C347BA4C-BFB2-4F24-852A-B113BB6D9C01}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{17CDCB1D-2FA9-4692-B1E6-456803EFB93B}','{9045F375-2050-4AB7-8A1A-6E221F0E0800}')
where
value like'%{17CDCB1D-2FA9-4692-B1E6-456803EFB93B}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{C8EE7077-1134-41A3-A9ED-BF3DB66324B4}','{9045F375-2050-4AB7-8A1A-6E221F0E0800}')
where
value like'%{C8EE7077-1134-41A3-A9ED-BF3DB66324B4}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{575205CF-7060-4E13-964E-7B1258C3FF89}','{0BEED865-5629-40F8-A3D0-EF16C03B79DD}')
where
value like'%{575205CF-7060-4E13-964E-7B1258C3FF89}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{E0F24299-AB26-41DD-9636-B9EF5F8EADDD}','{0BEED865-5629-40F8-A3D0-EF16C03B79DD}')
where
value like'%{E0F24299-AB26-41DD-9636-B9EF5F8EADDD}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{5DD2C2A1-350E-418D-853A-027B6431BFE2}','{0BEED865-5629-40F8-A3D0-EF16C03B79DD}')
where
value like'%{5DD2C2A1-350E-418D-853A-027B6431BFE2}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{0178E7D8-4EF9-41D1-8F42-6E8612F88137}','{B29899F8-44F3-4268-98FC-D736C6AED577}')
where
value like'%{0178E7D8-4EF9-41D1-8F42-6E8612F88137}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{737247A6-1F73-40CE-905C-1B3120F069C5}','{B29899F8-44F3-4268-98FC-D736C6AED577}')
where
value like'%{737247A6-1F73-40CE-905C-1B3120F069C5}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{0A16DA85-238F-4076-9A1A-3E43BFBF36FF}','{B29899F8-44F3-4268-98FC-D736C6AED577}')
where
value like'%{0A16DA85-238F-4076-9A1A-3E43BFBF36FF}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{9EE8A222-099A-44E5-8A98-D8291DBF56E5}','{53A83916-7CBB-4610-843B-C4EB6E9CCE9A}')
where
value like'%{9EE8A222-099A-44E5-8A98-D8291DBF56E5}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{E892CFB0-F61F-4242-9782-6FC6FD108E5C}','{53A83916-7CBB-4610-843B-C4EB6E9CCE9A}')
where
value like'%{E892CFB0-F61F-4242-9782-6FC6FD108E5C}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{21EEBFDB-A8C3-4BD4-BCA2-3971CF77CEE8}','{53A83916-7CBB-4610-843B-C4EB6E9CCE9A}')
where
value like'%{21EEBFDB-A8C3-4BD4-BCA2-3971CF77CEE8}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{C80BB0F0-7A83-4640-9783-8C0208964F76}','{C80BB0F0-7A83-4640-9783-8C0208964F76}')
where
value like'%{C80BB0F0-7A83-4640-9783-8C0208964F76}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{C80BB0F0-7A83-4640-9783-8C0208964F76}','{C80BB0F0-7A83-4640-9783-8C0208964F76}')
where
value like'%{C80BB0F0-7A83-4640-9783-8C0208964F76}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_keyitem t
set t.value=replace(t.value,'{C80BB0F0-7A83-4640-9783-8C0208964F76}','{C80BB0F0-7A83-4640-9783-8C0208964F76}')
where
value like'%{C80BB0F0-7A83-4640-9783-8C0208964F76}%'
and t.request_id in
(select r.request_id
from cca_request r);
update cca_request r
set r.status='COMPLETED'
where r.status='UNDELIVERABLE' and r.status_message like '%Codemap not found%';
commit;
spool off

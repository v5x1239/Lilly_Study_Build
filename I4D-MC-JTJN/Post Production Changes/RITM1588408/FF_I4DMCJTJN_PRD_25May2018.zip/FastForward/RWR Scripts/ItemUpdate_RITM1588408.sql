rem	DESCR:
rem
rem	This SQL will spool xml, which on cooking, associates latest item revision number 
rem	with all existing section revisions.
rem	Example: Any updates to item properties, updates to codelist attached to the item etc.	
rem 	Usage : sqlplus <trialuser>/<password>@<database> @ItemUpdate.sql
Set echo off;
set pagesize 0;
set linesize 500;
set head off;
set feed off;
set termout off;
set verify off;
set trimspool on;
set recsep off;
set wrap off;
set spa 0;

spool UpdateSectionItem_RITM1588408.xml
					

select '<?xml version="1.0"?><MEDMLDATA xmlns="PhaseForward-MedML-Inform4">' from dual
/
--Form change SU1001_LF2
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='SUNCF_ALCOHOL_SU1001_F2'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igSU1001_F2_S1'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change HRFA1001_F1 1
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='HRFARES7_HRFA1001_F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igHRFA1001_F1_S4'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change HRFA1001_F1 2
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='HRFARES9_HRFA1001_F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igHRFA1001_F1_S4'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change SU1001_LF3
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='SUDOSADJ_ALCOHOL_SU1F3'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igSU1001_F3_S1'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change HRFA1001_C1F1 1
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='HRFARES7_HRFA1001_C1F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igHRFA1001_C1F1_S4'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change HRFA1001_C1F1 2
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='HRFARES9_HRFA1001_C1F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igHRFA1001_C1F1_S4'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 1
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A10_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A10'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 2
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A27_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A27'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 3
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A14_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A14'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 4
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A15_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A15'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 5
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A16_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A16'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 6
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A17_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A17'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 7
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBRESMD_A20_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_A20'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 8
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A10_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 9
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A27_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 10
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A14_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 11
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A15_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 12
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A16_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 13
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A17_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

--Form change LB9001_LF1 17
select 
'<UPDATE_SECTION_ITEM'||chr(13)||						
' SECTION_REFNAME="'||s.sectionrefname||'"'||chr(13)||
' SECTION_REVISION="'||s.sectionrevisionnumber||'"'||chr(13)|| 
' ITEM_REFNAME="'||i.itemrefname||'"'||chr(13)||
' ITEM_REVISION="'||i.itemrevisionnumber||'"/>'||chr(13)
from pf_item i,
     pf_section s
where i.itemrefname='LBTEST_GLS_A20_LB9F1'
and i.itemrevisionnumber = (select max(i2.itemrevisionnumber) from pf_item i2 where i.itemid=i2.itemid)
and s.sectionrefname='igLB9001_F1_LAST'
and s.sectionrevisionnumber in (select distinct s2.sectionrevisionnumber from 	pf_section s2,
										pf_pagesection d, 
 										pf_vechapterpage e,
       										pf_page f,
       										pf_VeChapter g,
       										pf_volumeedition h
				where s.sectionid=s2.sectionid
                                  and s.sectionrevisionnumber=s2.sectionrevisionnumber
                                  and s.sectionid=d.sectionid
                                  and s.sectionrevisionnumber=d.sectionrevisionnumber
				  and d.pageid=e.pageid
   				  and d.pagerevisionnumber = e.pagerevisionnumber
  				  and d.pageid=f.pageid
   				  and d.pagerevisionnumber = f.pagerevisionnumber
   				  and e.chapterid=g.chapterid
   				  and e.chapterrevisionnumber=g.chapterrevisionnumber
   				  and g.volumeeditionid=h.volumeeditionid)
				  --and h.editiondescription = 'Study Version 1.5.1 en-US')
/

select '</MEDMLDATA>' from dual
/
spool off

exit

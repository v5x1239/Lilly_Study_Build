@UndeleteForm_INF_15385.sql;
@fixdynamics.sql;
@InactivateCCTriggers.sql;
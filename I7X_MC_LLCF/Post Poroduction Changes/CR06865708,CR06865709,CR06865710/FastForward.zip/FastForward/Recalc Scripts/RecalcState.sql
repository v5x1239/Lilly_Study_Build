/*
**desc: recalculate the state for inform
** login as trialuid and trialpid
*/
spool recalcstate.log

Update PF_SubjectVEChapterPage set NeedsRecalcState = 1 
where 
NeedsRecalcState IS NULL and startedstate > 0 and
pageid in 
	(select distinct pageid from pf_page where pagerefname in ('EX1001_C1F1','ADASS3001_F1','CSS07001_F1','AE3001_LF1','DM1001_LF1','MHPRESP1001_APMH1001_F1','IOP2001_F1','VS1001_F3','VS1001_F4'))
and subjectchapterid in
	(select subjectchapterid from PF_SubjectVEChapter 
  	 where subjectkeyid in 
  	 	(select patientid from pf_patient where state > 3));

COMMIT;
spool off;
exit;
